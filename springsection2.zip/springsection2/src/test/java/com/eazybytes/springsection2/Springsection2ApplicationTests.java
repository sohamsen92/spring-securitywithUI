package com.eazybytes.springsection2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springsection2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
